public class Main {
    public static void main(String[] args) {

        int age = 12;
        if (age < 0) {
            System.out.println("Wrong request");
        }
        if (age < 18) {
            System.out.println("You are underage!");
        } else {
            System.out.println("You are adult!");
        }



        int n = 50;
        n++;
        int m = n / 2;
        int a = m * 50;
        {
            System.out.print("answer" + a);
        }


        int year = 4;
        int sailory = 3000;
        double i = sailory + (sailory*0.1);
        double u = sailory + (sailory * 0.2);
        double bonus = i + 1000;
       double donus = u + 500;

        if ((year<=3) && (sailory<4000)){
            System.out.println("bonus-"+bonus);
        }
         if ((year<=3) && (sailory>4000)){
            System.out.println("You sailory is up!"+i);
        }

        if ((year>3) && (sailory<4000)){
            System.out.println("bonus-"+donus);
        }
        if ((year>3) && (sailory>4000)){
            System.out.println("You sailory is up!"+u);
        }

    }
}